import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTabbedPane tabbedPane1;
    private JButton btnAgregar;
    private JButton btnReset;
    private JLabel txtPlac;
    private JLabel cboMarc;
    private JLabel txtModel;
    private JLabel sp;
    private JTextField txtPlaca;
    private JTextField txtModelo;
    private JComboBox cboMarca;
    private JSpinner spAnio;
    private JTextArea txtListado;
    private JButton btnListar;
    private JButton btnPagar;
    private JLabel lblPago;
    private JComboBox cboBuscar;
    private JTextArea txtBuscar;
    private JButton btnBuscar;
    private ColaAutos autos = new ColaAutos();

    public Ventana(){
        spAnio.setModel(new SpinnerNumberModel(2025, 1995, 2026, 1));
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtPlaca.setText("");
                txtModelo.setText("");
                cboMarca.setSelectedIndex(0);
            }
        });
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String placa=txtPlaca.getText();
                String marca=cboMarca.getSelectedItem().toString();
                String modelo=txtModelo.getText();
                int anio= Integer.parseInt(spAnio.getValue().toString());
                Auto a = new Auto(placa, marca, modelo, anio);
                autos.encolar(a);
                JOptionPane.showMessageDialog(null, "Se agrego correctamente un auto");
            }
        });
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                txtListado.setText(autos.toString());

            }
        });
        btnPagar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
                    Auto actual = autos.desencolar();
                    float pago=0;
                    if(actual.getAnio()>=2000){
                        pago=50.49f;}
                    else {
                        pago =120.99f;
                    } lblPago.setText("Pago por el " + actual.toString() + " debe pagar: " + pago);
                    txtListado.setText(autos.toString());
                } catch (Exception ex){
                    JOptionPane.showMessageDialog(null, ex.getMessage());
                }
            }
        });
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //Auto buscarauto =
                //if()
                txtBuscar.setText(autos.toString());
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

}
