import java.util.LinkedList;
import java.util.Queue;

public class ColaAutos {
    private Queue<Auto> ListaAutos;

    public ColaAutos() {
        ListaAutos = new LinkedList<Auto>();
    }

    public void encolar(Auto auto){
        ListaAutos.add(auto);
    }

    public Auto desencolar() throws Exception{
        if(ListaAutos.isEmpty()){
            throw new Exception("No hay mas autos");

        }
        return ListaAutos.poll();
    }

    @Override
    public String toString() {
        StringBuilder acum=new StringBuilder();

        for(Auto dato:ListaAutos){
            acum.append(dato.toString());
        }
        return "Lista de Autos: " + acum.toString();
    }
}
