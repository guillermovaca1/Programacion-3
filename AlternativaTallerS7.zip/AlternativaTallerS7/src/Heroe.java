public class Heroe {

    private int id;
    private String nombre;
    private String superpoder;
    private String mision;
    private int nivelDificultad;
    private double pagoMensual;

    public Heroe(int id, String nombre, String superpoder,
                 String mision, int nivelDificultad, double pagoMensual) {
        this.id = id;
        this.nombre = nombre;
        this.superpoder = superpoder;
        this.mision = mision;
        setNivelDificultad(nivelDificultad);
        setPagoMensual(pagoMensual);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSuperpoder() {
        return superpoder;
    }

    public void setSuperpoder(String superpoder) {
        this.superpoder = superpoder;
    }

    public String getMision() {
        return mision;
    }

    public void setMision(String mision) {
        this.mision = mision;
    }

    public int getNivelDificultad() {
        return nivelDificultad;
    }

    public void setNivelDificultad(int nivelDificultad) {
        if (nivelDificultad < 1) {
            this.nivelDificultad = 1;
        } else if (nivelDificultad > 5) {
            this.nivelDificultad = 5;
        } else {
            this.nivelDificultad = nivelDificultad;
        }
    }

    public double getPagoMensual() {
        return pagoMensual;
    }

    public void setPagoMensual(double pagoMensual) {
        if (pagoMensual < 0) {
            pagoMensual = 0;
        }
        this.pagoMensual = pagoMensual;
    }

    public double calcularAporteFondo() {
        return pagoMensual * 0.10;
    }

    public double calcularPagoAnualBruto() {
        return pagoMensual * 12;
    }

    public double calcularImpuestoAnual() {
        double pagoAnual = calcularPagoAnualBruto();
        double impuestoAnual = 0.0;

        if (pagoAnual <= 60000) {
            impuestoAnual = 0;
        } else if (pagoAnual <= 120000) {
            impuestoAnual = (pagoAnual - 60000) * 0.12;
        } else if (pagoAnual <= 240000) {
            impuestoAnual = (pagoAnual - 120000) * 0.25;
        } else {
            impuestoAnual = (pagoAnual - 240000) * 0.35;
        }

        return impuestoAnual;
    }

    public double calcularImpuestoMensual() {
        return calcularImpuestoAnual() / 12.0;
    }

    public double calcularPagoNetoMensual() {
        double aporte = calcularAporteFondo();
        double impuestoMensual = calcularImpuestoMensual();
        return pagoMensual - aporte - impuestoMensual;
    }

    @Override
    public String toString() {
        return "Héroe " +
                "ID: " + id +
                ", Nombre: " + nombre +
                ", Superpoder: " + superpoder +
                ", Misión: " + mision +
                ", Nivel: " + nivelDificultad +
                ", Pago mensual: " + pagoMensual;
    }
}