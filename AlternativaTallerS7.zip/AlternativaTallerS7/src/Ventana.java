import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class Ventana {
    private JPanel principal;
    private JTabbedPane tabbedPane1;
    private JList<Heroe> lstHeroes;
    private JButton btnListar;
    private JTabbedPane tabbedPane2;
    private JTextField txtID;
    private JTextField txtNombre;
    private JTextField txtSuperpoder;
    private JTextField txtMision;
    private JTextField txtPagoMensual;
    private JSpinner spiNivelDificultad;
    private JButton btnIngresar;
    private JTextField txtActualizarID;
    private JTextField txtActualizarNombre;
    private JTextField txtActualizarSuperpoder;
    private JTextField txtActualizarmision;
    private JTextField txtActualizarPagoMensual;
    private JSpinner spiActualizarDificultad;
    private JButton btnActualizar;
    private JTextArea txtReporte;
    private JButton btnReporte;
    private JButton btnBuscar;
    private JButton btnEliminar;

    private HeroeManager manager = new HeroeManager();

    public Ventana() {

        spiNivelDificultad.setModel(new SpinnerNumberModel(1, 1, 5, 1));
        spiActualizarDificultad.setModel(new SpinnerNumberModel(1, 1, 5, 1));

        manager.cargarDatosPrueba();
        llenarLista(manager.listarHeroesOrdenadosPorId());

        configurarEventos();
    }

    private void configurarEventos() {

        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                llenarLista(manager.listarHeroesOrdenadosPorId());
            }
        });

        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ingresarHeroe();
            }
        });

        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarHeroeParaEditar();
            }
        });

        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarHeroe();
            }
        });

        btnReporte.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });

        if (btnEliminar != null) {
            btnEliminar.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    int index = lstHeroes.getSelectedIndex();
                    if (index != -1) {
                        if (manager.eliminarHeroePorIndice(index)) {
                            JOptionPane.showMessageDialog(null, "Héroe eliminado.");
                            llenarLista(manager.listarHeroesOrdenadosPorId());
                        } else {
                            JOptionPane.showMessageDialog(null, "No se pudo eliminar el héroe.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Seleccione un héroe de la lista.");
                    }
                }
            });
        }
    }

    private void llenarLista(List<Heroe> heroes) {
        DefaultListModel<Heroe> modelo = new DefaultListModel<>();
        for (Heroe h : heroes) {
            modelo.addElement(h);
        }
        lstHeroes.setModel(modelo);
    }

    private void ingresarHeroe() {
        try {
            int id = Integer.parseInt(txtID.getText().trim());
            String nombre = txtNombre.getText().trim();
            String superpoder = txtSuperpoder.getText().trim();
            String mision = txtMision.getText().trim();
            int nivel = (Integer) spiNivelDificultad.getValue();
            double pagoMensual = Double.parseDouble(txtPagoMensual.getText().trim());

            if (id <= 0) {
                JOptionPane.showMessageDialog(null, "El ID debe ser un entero positivo.");
                return;
            }

            if (nombre.isEmpty() || superpoder.isEmpty() || mision.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Complete todos los campos.");
                return;
            }

            Heroe h = new Heroe(id, nombre, superpoder, mision, nivel, pagoMensual);

            if (manager.agregarHeroe(h)) {
                JOptionPane.showMessageDialog(null, "Héroe ingresado.");
                limpiarCamposIngreso();
                llenarLista(manager.listarHeroesOrdenadosPorId());
            } else {
                JOptionPane.showMessageDialog(null, "Ya existe un héroe con ese ID.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "ID y Pago Mensual deben ser números.");
        }
    }

    private void buscarHeroeParaEditar() {
        try {
            int id = Integer.parseInt(txtActualizarID.getText().trim());
            Heroe h = manager.buscarPorId(id);

            if (h == null) {
                JOptionPane.showMessageDialog(null, "No existe un héroe con ese ID.");
                return;
            }

            txtActualizarNombre.setText(h.getNombre());
            txtActualizarSuperpoder.setText(h.getSuperpoder());
            txtActualizarmision.setText(h.getMision());
            spiActualizarDificultad.setValue(h.getNivelDificultad());
            txtActualizarPagoMensual.setText(String.valueOf(h.getPagoMensual()));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese un ID válido.");
        }
    }

    private void actualizarHeroe() {
        try {
            int id = Integer.parseInt(txtActualizarID.getText().trim());
            String nombre = txtActualizarNombre.getText().trim();
            String superpoder = txtActualizarSuperpoder.getText().trim();
            String mision = txtActualizarmision.getText().trim();
            int nivel = (Integer) spiActualizarDificultad.getValue();
            double pagoMensual = Double.parseDouble(txtActualizarPagoMensual.getText().trim());

            if (nombre.isEmpty() || superpoder.isEmpty() || mision.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Complete todos los campos.");
                return;
            }

            boolean ok = manager.actualizarHeroe(id, nombre, superpoder, mision, nivel, pagoMensual);

            if (ok) {
                JOptionPane.showMessageDialog(null, "Héroe actualizado.");
                llenarLista(manager.listarHeroesOrdenadosPorId());
            } else {
                JOptionPane.showMessageDialog(null, "No existe un héroe con ese ID.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "ID y Pago Mensual deben ser números.");
        }
    }

    private void generarReporte() {
        String input = JOptionPane.showInputDialog(null, "Ingrese el ID para generar reporte:");

        if (input == null) return;

        try {
            int id = Integer.parseInt(input);
            ReporteHeroe r = manager.generarReporte(id);

            if (r != null) {
                txtReporte.setText(r.toString());
            } else {
                JOptionPane.showMessageDialog(null, "ID no encontrado.");
                txtReporte.setText("");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
        }
    }

    private void limpiarCamposIngreso() {
        txtID.setText("");
        txtNombre.setText("");
        txtSuperpoder.setText("");
        txtMision.setText("");
        txtPagoMensual.setText("");
        spiNivelDificultad.setValue(1);
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Liga de la Justicia - Alternativa 2");
        frame.setContentPane(new Ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }
}
