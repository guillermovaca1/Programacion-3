import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class HeroeManager {

    private List<Heroe> heroes;

    public HeroeManager() {
        heroes = new ArrayList<>();
    }

    public List<Heroe> getHeroes() {
        return heroes;
    }

    public boolean agregarHeroe(Heroe heroe) {
        for (Heroe h : heroes) {
            if (h.getId() == heroe.getId()) {
                return false; // ID duplicado
            }
        }
        heroes.add(heroe);
        return true;
    }

    public Heroe buscarPorId(int id) {
        for (Heroe h : heroes) {
            if (h.getId() == id) {
                return h;
            }
        }
        return null;
    }

    public boolean actualizarHeroe(int id, String nombre, String superpoder,
                                   String mision, int nivelDificultad,
                                   double pagoMensual) {
        for (Heroe h : heroes) {
            if (h.getId() == id) {
                h.setNombre(nombre);
                h.setSuperpoder(superpoder);
                h.setMision(mision);
                h.setNivelDificultad(nivelDificultad);
                h.setPagoMensual(pagoMensual);
                return true;
            }
        }
        return false;
    }


    public boolean eliminarHeroePorIndice(int index) {
        if (index >= 0 && index < heroes.size()) {
            heroes.remove(index);
            return true;
        }
        return false;
    }

    public List<Heroe> listarHeroes() {
        return new ArrayList<>(heroes);
    }


    public List<Heroe> listarHeroesOrdenadosPorId() {
        List<Heroe> lista = new ArrayList<>(heroes);
        lista.sort(Comparator.comparingInt(Heroe::getId));
        return lista;
    }

    public ReporteHeroe generarReporte(int id) {
        Heroe h = buscarPorId(id);
        if (h == null) return null;

        return new ReporteHeroe(
                h.getNombre(),
                h.getSuperpoder(),
                h.getPagoMensual(),
                h.calcularAporteFondo(),
                h.calcularImpuestoMensual(),
                h.calcularPagoNetoMensual()
        );
    }

    public void cargarDatosPrueba() {
        Heroe h1 = new Heroe(1, "Batman", "Estrategia", "Patrullar Gotham", 3, 5000);
        Heroe h2 = new Heroe(2, "Superman", "Super fuerza", "Salvar Metrópolis", 5, 15000);
        Heroe h3 = new Heroe(3, "Cyborg", "Inteligencia", "Desarrollar tecnología", 2, 10000);

        agregarHeroe(h1);
        agregarHeroe(h2);
        agregarHeroe(h3);
    }
}
