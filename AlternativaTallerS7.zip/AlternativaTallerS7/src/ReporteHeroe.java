public class ReporteHeroe {

    private String nombre;
    private String superpoder;
    private double pagoMensual;
    private double aporte;
    private double impuestoMensual;
    private double pagoNeto;

    public ReporteHeroe(String nombre, String superpoder, double pagoMensual,
                        double aporte, double impuestoMensual, double pagoNeto) {
        this.nombre = nombre;
        this.superpoder = superpoder;
        this.pagoMensual = pagoMensual;
        this.aporte = aporte;
        this.impuestoMensual = impuestoMensual;
        this.pagoNeto = pagoNeto;
    }

    public String getNombre() {
        return nombre;
    }

    public String getSuperpoder() {
        return superpoder;
    }

    public double getPagoMensual() {
        return pagoMensual;
    }

    public double getAporte() {
        return aporte;
    }

    public double getImpuestoMensual() {
        return impuestoMensual;
    }

    public double getPagoNeto() {
        return pagoNeto;
    }

    @Override
    public String toString() {
        return "Reporte del Héroe:\n" +
                "Nombre: " + nombre +
                "\nSuperpoder: " + superpoder +
                "\nPago mensual: $" + String.format("%.2f", pagoMensual) +
                "\nAporte al Fondo: $" + String.format("%.2f", aporte) +
                "\nImpuesto mensual: $" + String.format("%.2f", impuestoMensual) +
                "\nPago neto mensual: $" + String.format("%.2f", pagoNeto);
    }
}

