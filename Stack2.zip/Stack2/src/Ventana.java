import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTextArea txtCodigo;
    private JButton btnComprobar;
    private JLabel lbResultado;
    private Pila pila=new Pila();

    public Ventana() {
        btnComprobar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    String codigo = txtCodigo.getText();
                    if (pila.balanceada(codigo) == true) {
                        lbResultado.setText("Codigo Balanceado");
                    } else {
                        lbResultado.setText("Codigo no balanceaedo");
                    }
                }
                catch(Exception ex){
                    lbResultado.setText(ex.getMessage());
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
