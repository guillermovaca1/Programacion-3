import java.util.Stack;

public class Pila {

    private Stack<Character> pila;

    public Pila(){
        pila =new Stack<Character>();
    }

    public boolean esVacia(){
        return pila.isEmpty();
    }

    public void push(Character c){
        pila.push(c);
    }

    public Character pop() throws Exception {
        if(esVacia())
            throw new Exception("No balanceada");
        return pila.pop();
    }

    public boolean balanceada(String cadena) throws Exception {
        Pila p1 = new Pila();
       for(int i=0; i<cadena.length(); i++){
           if(cadena.charAt(i)=='('){
               p1.push(cadena.charAt(i));
           } else{
               if(cadena.charAt(i)==')'){
                   if(p1.pop()!='(')
                       return false;
               }
           }
       }
       if(p1.esVacia())
           return true;
       return false;
    }

}