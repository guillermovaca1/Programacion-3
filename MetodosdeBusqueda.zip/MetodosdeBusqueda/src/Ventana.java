import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTabbedPane tabbedPane1;
    private JTextField txtID;
    private JTextField txtNombre;
    private JComboBox cboPosicion;
    private JSpinner spiRendimiento;
    private JButton btnAgregar;
    private JButton btnEditar;
    private JList lstEquipo;
    private JButton btnMostrar;
    int codigo = 0;
    Equipo equipo1 = new Equipo();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }

    public Ventana() {
        SpinnerNumberModel snm = new SpinnerNumberModel(10,1,20,1);
        spiRendimiento.setModel(snm);
        btnAgregar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(txtID.getText());
                String nombre = txtNombre.getText();
                String pos = cboPosicion.getSelectedItem().toString();
                int rendi = Integer.parseInt(spiRendimiento.getValue().toString());
                if(id<=codigo){
                    JOptionPane.showMessageDialog(null, "ID no valido");
                } else {
                    Jugador j = new Jugador(id,nombre,pos,rendi);
                    equipo1.agregar(j);
                    JOptionPane.showMessageDialog(null, "Jugador Agregado");
                    codigo=id;
                }

            }
        });
        btnMostrar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultListModel dl = new DefaultListModel();
                for(Jugador j: equipo1.todos()){
                    dl.addElement(j.toString());
                }
                lstEquipo.setModel(dl);
            }
        });
        btnEditar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int id = Integer.parseInt(txtID.getText());
                String nombre = txtNombre.getText();
                String pos = cboPosicion.getSelectedItem().toString();
                int rendi = Integer.parseInt(spiRendimiento.getValue().toString());
                Jugador editar = new Jugador(id, nombre, pos, rendi);
                if(equipo1.editar(id,editar)){
                    JOptionPane.showMessageDialog(null,"Edicion correcta, muestre los datos");
                } else {
                    JOptionPane.showMessageDialog(null, "El ID no existe");}
                }
            });
        lstEquipo.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if(lstEquipo.getSelectedIndex()!=-1){
                    int indice=lstEquipo.getSelectedIndex();
                    Jugador seleccionado = equipo1.todos().get(indice);
                    txtID.setText(""+seleccionado.getId());
                    txtNombre.setText((seleccionado.getNombre()));
                    cboPosicion.setSelectedItem(seleccionado.getPosicion());
                    spiRendimiento.setValue(seleccionado.getRendimiento());
                    JOptionPane.showMessageDialog(null,"Revise los datos en el ingreso");
                }
            }
        });
    }

    }
