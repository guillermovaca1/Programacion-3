public class Empleado {
    private int codigo;
    private String nombre;
    private String puesto;
    private float sueldoBase;
    private float bonificacion;
    private float retencion;

    public Empleado(int codigo, String nombre, String puesto, float sueldoBase, float bonificacion, float retencion) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.puesto = puesto;
        this.sueldoBase = sueldoBase;
        this.bonificacion = bonificacion;
        this.retencion = retencion;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getPuesto() {
        return puesto;
    }

    public void setPuesto(String puesto) {
        this.puesto = puesto;
    }

    public float getSueldoBase() {
        return sueldoBase;
    }

    public void setSueldoBase(float sueldoBase) {
        this.sueldoBase = sueldoBase;
    }

    public float getBonificacion() {
        return bonificacion;
    }

    public void setBonificacion(float bonificacion) {
        this.bonificacion = bonificacion;
    }

    public float getRetencion() {
        return retencion;
    }

    public void setRetencion(float retencion) {
        this.retencion = retencion;
    }

    @Override
    public String toString() {
        return "Empleado: " + "\n" +
                "codigo= " + codigo +
                ", nombre= " + nombre + '\'' +
                ", puesto= " + puesto + '\'' +
                ", sueldoBase =" + sueldoBase +
                ", bonificacion= " + bonificacion +
                ", retencion= " + retencion;
    }
}
