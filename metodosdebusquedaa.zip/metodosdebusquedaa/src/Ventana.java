import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTabbedPane tabbedPane1;
    private JList lstNomina;
    private JButton btnOrdenar;
    private JButton btnSalario;
    private JLabel lblSumar;
    private JButton btnEliminar;
    private JButton btnAgregar;
    Empresa miEmpresa =new Empresa();


    public void llenarJlist(){
        DefaultListModel dlm = new DefaultListModel<>();
        for(Empleado empleado:miEmpresa.getNomina()){
            dlm.addElement(empleado);
        }
        lstNomina.setModel(dlm);
    }

    public Ventana() {

        llenarJlist();
        lblSumar.setText("Suma total de impares: "+ miEmpresa.suma(0));
        btnOrdenar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                miEmpresa.ordenar();
                llenarJlist();
            }
        });
        btnSalario.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                miEmpresa.ordenarSalario();
                llenarJlist();
            }
        });
        btnEliminar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                /*if(lstNomina.getSelectedIndex()!=-1){
                Empleado aux = miEmpresa.nomina.get(lstNomina.getSelectedIndex());
                    for(Empleado empleado: miEmpresa.getNomina()){
                        if(empleado.getCodigo() == aux.getCodigo()){
                            aux=empleado;

                        }
                    }
                    if(miEmpresa.getNomina().remove(aux)){
                        JOptionPane.showMessageDialog(null,"Empleado Eliminado");
                        llenarJlist();
                    } else {
                        JOptionPane.showMessageDialog(null, "No se pudo eliminar");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione un elemento de la lista");
                }*/

                int index = lstNomina.getSelectedIndex();
                if(index!=-1){
                    miEmpresa.getNomina().remove(index);
                    JOptionPane.showMessageDialog(null,"Empleado Eliminado");
                    llenarJlist();
                } else {
                    JOptionPane.showMessageDialog(null, "Seleccione un empleado de la lista");
                }
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
