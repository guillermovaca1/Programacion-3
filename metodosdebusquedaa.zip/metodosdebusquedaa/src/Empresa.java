import java.util.ArrayList;
import java.util.List;

public class Empresa {

    List<Empleado> nomina;


    public void predefinir(){
        Empleado empleado1 = new Empleado(4,"David","Director",1000,100.50f,250.98f);
        Empleado empleado2 = new Empleado(7,"Henry","Conserje",69,0.50f,50.98f);
        Empleado empleado3 = new Empleado(3,"Guillermo","Gerente",20000,200.50f,350.98f);
        Empleado empleado4 = new Empleado(6,"Gregory","Director de Marketing",3000,300.50f,450.98f);
        Empleado empleado5 = new Empleado(1,"Israel","Asesor",6900,250.50f,200.98f);

        nomina.add(empleado1);
        nomina.add(empleado2);
        nomina.add(empleado3);
        nomina.add(empleado4);
        nomina.add(empleado5);
    }


    public Empresa() {
        this.nomina = new ArrayList<Empleado>();
        predefinir();
    }

    public void agregar(Empleado empleado){
        nomina.add(empleado);
    }

    public void ordenar(){
        Empleado aux;
        for(int i = 0; i < nomina.size()-1; i++){

            for (int j=i+1; j<nomina.size();j++){
                if (nomina.get(i).getCodigo()>nomina.get(j).getCodigo()){
                    aux = nomina.get(i);
                    nomina.set(i,nomina.get(j));
                    nomina.set(j,aux);
                }
            }

        }
    }

    public void ordenarSalario(){
        Empleado aux;
        int j;

        for (int i =1; i< nomina.size();i++){
            aux = nomina.get(i);
            j=i-1;
            while(j>=0 && aux.getSueldoBase()<nomina.get(j).getSueldoBase()){
                nomina.set(j+1, nomina.get(j));
                j--;
            }
            nomina.set(j+1, aux);
        }
    }



    public List<Empleado> getNomina() {
        return nomina;
    }

    public float suma(int index){
        if (nomina.size() == index){
            return 0;
        } else {
            if (nomina.get(index).getCodigo()%2==0){
                return 0+suma(index+1);
            } else {
                return nomina.get(index).getSueldoBase()+suma(index+1);
            }
        }
    }

}
