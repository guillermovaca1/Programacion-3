//Guillermo Vaca, Henry Olmedo

public class Compra {

    private String cliente;
    private String pelicula;
    private int cantidad;
    private double precioBoleto;

    public Compra(String cliente, String pelicula, int cantidad, double precioBoleto) {
        this.cliente = cliente;
        this.pelicula = pelicula;
        this.cantidad = cantidad;
        this.precioBoleto = precioBoleto;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    public String getPelicula() {
        return pelicula;
    }

    public void setPelicula(String pelicula) {
        this.pelicula = pelicula;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public double getPrecioBoleto() {
        return precioBoleto;
    }

    public void setPrecioBoleto(double precioBoleto) {
        this.precioBoleto = precioBoleto;
    }

    public double setTotal(){
        return precioBoleto* cantidad;
    }

    @Override
    public String toString() {
        return "Compra: " +
                "Cliente: " + cliente +
                ", Pelicula: " + pelicula +
                ", Entradas: " + cantidad +
                ", Precio boleto por Unidad: " + precioBoleto+
                ",Total: " + setTotal()+ "\n";
    }
}
