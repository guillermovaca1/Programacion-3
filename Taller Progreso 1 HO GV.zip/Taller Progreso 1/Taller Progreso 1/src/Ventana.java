import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JComboBox cboPelicula;
    private JTextField txtNombre;
    private JButton btnComprar;
    private JTextArea txtCompras;
    private JSpinner spCantidad;
    private JTextArea txtXmen;
    private JTextArea txtMario;
    private JTextArea txtBatman;
    private JTextPane txtTotal;

    private ColaCompras compras = new ColaCompras();
    private final int Capacidad = 23;
    private int vendX= 0, vendM= 0, vendB = 0;
    private double total= 0.0;


    public Ventana() {

        spCantidad.setModel(new SpinnerNumberModel(1,1,
                4,1));

        btnComprar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre= txtNombre.getText();
                String pelicula=cboPelicula.getSelectedItem().toString();

                int cantidad=Integer.parseInt(spCantidad.getValue().toString());
                if(nombre.isEmpty()){
                    JOptionPane.showMessageDialog(null,"Ingrese el nombre del Cliente");
                    return;
                }

                int vendidosActuales = pelicula.equals("Xmen") ? vendX : pelicula.equals("Mario") ? vendM : vendB;
                if(vendidosActuales + cantidad > Capacidad){
                    int disp = Capacidad - vendidosActuales;
                    JOptionPane.showMessageDialog(null,"No hay cupos suficientes para " + pelicula + " disponibles solo: " + disp);
                    return;
                }

                double pUnit = precioDe(pelicula);
                Compra c = new Compra(nombre, pelicula, cantidad, pUnit);
                compras.encolar(c);

                if (pelicula.equals("Mario")) vendM +=cantidad;
                else if (pelicula.equals("Batman")) vendB += cantidad;
                else vendX += cantidad;

                total += c.setTotal();

                txtCompras.setText(compras.toString());
                actualizarEspacios();
                txtTotal.setText("Total recaudado: $" + String.format("%.2f", total));
                JOptionPane.showMessageDialog(null,"Gracias por su compra");

                txtNombre.setText("");
                spCantidad.setValue(1);
            }
        });

    }
    private double precioDe(String Pelicula){
        switch (Pelicula){
            case "Batman": return 3.75;
            case "Mario": return 3.25;
            default:    return 2.25;
        }
    }
    private void actualizarEspacios(){
        txtXmen.setText("Vendidos: "+ vendX + "\n" + "Disponibles: " +(Capacidad- vendX));
        txtMario.setText("Vendidos: "+ vendM + "\n" + "Disponibles: " +(Capacidad- vendM));
        txtBatman.setText("Vendidos: "+ vendB + "\n" + "Disponibles: " +(Capacidad- vendB));
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
