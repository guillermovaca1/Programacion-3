import java.util.LinkedList;
import java.util.Queue;

public class ColaCompras {
    private Queue<Compra> cola;

    public ColaCompras(){
        cola = new LinkedList<>();
    }
    public void encolar(Compra compra){
        cola.add(compra);
    }
    public boolean estaVacia(){
        return cola.isEmpty();
    }

    @Override
    public String toString() {
        StringBuilder ts = new StringBuilder();
        for (Compra compra : cola){
            ts.append(compra.toString());
        }
        return ts.toString();
    }
}
