import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HeroeManager {

    private Map<Integer, Heroe> heroes;

    public HeroeManager() {
        heroes = new HashMap<>();

    }

    public boolean agregarHeroe(Heroe heroe) {
        if (heroes.containsKey(heroe.getId())) {
            return false; // ID duplicado
        }
        heroes.put(heroe.getId(), heroe);
        return true;
    }

    public Heroe buscarPorId(int id) {
        return heroes.get(id);
    }

    public boolean actualizarHeroe(int id, String nombre, String superpoder,
                                   String mision, int nivelDificultad,
                                   double pagoMensual) {
        Heroe h = heroes.get(id);
        if (h == null) {
            return false;
        }
        h.setNombre(nombre);
        h.setSuperpoder(superpoder);
        h.setMision(mision);
        h.setNivelDificultad(nivelDificultad);
        h.setPagoMensual(pagoMensual);
        return true;
    }

    public boolean eliminarHeroe(int id) {
        return heroes.remove(id) != null;
    }


    public List<Heroe> listarHeroes() {
        return new ArrayList<>(heroes.values());
    }


    public List<Heroe> listarHeroesOrdenadosPorId() {
        List<Heroe> lista = new ArrayList<>(heroes.values());
        lista.sort((h1, h2) -> Integer.compare(h1.getId(), h2.getId()));
        return lista;
    }

    public List<Heroe> listarHeroesOrdenadosPorPagoMensual() {
        List<Heroe> lista = new ArrayList<>(heroes.values());
        lista.sort((h1, h2) -> Double.compare(h1.getPagoMensual(), h2.getPagoMensual()));
        return lista;
    }

    public ReporteHeroe generarReporte(int id) {
        Heroe h = heroes.get(id);
        if (h == null) return null;

        return new ReporteHeroe(
                h.getNombre(),
                h.getSuperpoder(),
                h.getPagoMensual(),
                h.calcularAporteFondo(),
                h.calcularImpuestoMensual(),
                h.calcularPagoNetoMensual()
        );
    }

    public void cargarDatosPrueba() {
        Heroe h1 = new Heroe(1, "Batman", "Estrategia", "Patrullar Gotham", 3, 5000);
        Heroe h2 = new Heroe(2, "Superman", "Super fuerza", "Salvar Metropolis", 5, 15000);
        Heroe h3 = new Heroe(3, "Cyborg", "Inteligencia", "Generar nueva tecnología", 2, 10000);

        agregarHeroe(h1);
        agregarHeroe(h2);
        agregarHeroe(h3);
    }
}
