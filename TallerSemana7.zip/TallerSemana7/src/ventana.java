import javax.swing.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ventana {
    private JPanel principal;
    private JTabbedPane tabbedPane1;
    private JTabbedPane tabbedPane2;
    private JList<Heroe> lstHeroes;
    private JButton btnListar;
    private JTextField txtID;
    private JTextField txtNombre;
    private JTextField txtSuperpoder;
    private JTextField txtMision;
    private JTextField txtPagoMensual;
    private JSpinner spiNivelDificultad;
    private JButton btnIngresar;
    private JTextField txtActualizarID;
    private JTextField txtActualizarNombre;
    private JTextField txtActualizarSuperpoder;
    private JTextField txtActualizarmision;
    private JTextField txtActualizarPagoMensual;
    private JSpinner spiActualizarDificultad;
    private JButton btnActualizar;
    private JTextArea txtReporte;
    private JButton btnReporte;
    private JButton btnBuscar; // <-- NECESARIO PARA EDITAR

    private HeroeManager manager = new HeroeManager();

    public static void main(String[] args) {
        JFrame frame = new JFrame("Liga de la Justicia");
        frame.setContentPane(new ventana().principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);
    }

    public ventana() {

        // Spinners limitados entre 1 y 5
        spiNivelDificultad.setModel(new SpinnerNumberModel(1, 1, 5, 1));
        spiActualizarDificultad.setModel(new SpinnerNumberModel(1, 1, 5, 1));

        manager.cargarDatosPrueba();

        llenarLista(manager.listarHeroesOrdenadosPorId());

        configurarEventos();
    }

    private void configurarEventos() {

        // LISTAR
        btnListar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                llenarLista(manager.listarHeroesOrdenadosPorId());
            }
        });

        // INGRESAR
        btnIngresar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ingresarHeroe();
            }
        });

        // BUSCAR EN EDITAR (nuevo)
        btnBuscar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                buscarHeroeParaEditar();
            }
        });

        // ACTUALIZAR
        btnActualizar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                actualizarHeroe();
            }
        });

        // REPORTE
        btnReporte.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                generarReporte();
            }
        });
    }

    // --------------------
    // LISTADO
    // --------------------
    private void llenarLista(List<Heroe> heroes) {
        DefaultListModel<Heroe> modelo = new DefaultListModel<>();
        for (Heroe h : heroes) {
            modelo.addElement(h);
        }
        lstHeroes.setModel(modelo);
    }

    // --------------------
    // INGRESAR
    // --------------------
    private void ingresarHeroe() {
        try {
            int id = Integer.parseInt(txtID.getText().trim());
            String nombre = txtNombre.getText().trim();
            String superpoder = txtSuperpoder.getText().trim();
            String mision = txtMision.getText().trim();
            int nivel = (Integer) spiNivelDificultad.getValue();
            double pagoMensual = Double.parseDouble(txtPagoMensual.getText().trim());

            if (nombre.isEmpty() || superpoder.isEmpty() || mision.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Complete todos los campos.");
                return;
            }

            Heroe h = new Heroe(id, nombre, superpoder, mision, nivel, pagoMensual);

            if (manager.agregarHeroe(h)) {
                JOptionPane.showMessageDialog(null, "Héroe ingresado.");
                limpiarCamposIngreso();
                llenarLista(manager.listarHeroesOrdenadosPorId());
            } else {
                JOptionPane.showMessageDialog(null, "Ya existe un héroe con ese ID.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "ID y Pago Mensual deben ser números.");
        }
    }

    // --------------------
    // BUSCAR PARA EDITAR
    // --------------------
    private void buscarHeroeParaEditar() {
        try {
            int id = Integer.parseInt(txtActualizarID.getText().trim());
            Heroe h = manager.buscarPorId(id);

            if (h == null) {
                JOptionPane.showMessageDialog(null, "No existe un héroe con ese ID.");
                return;
            }

            // Rellenamos campos
            txtActualizarNombre.setText(h.getNombre());
            txtActualizarSuperpoder.setText(h.getSuperpoder());
            txtActualizarmision.setText(h.getMision());
            spiActualizarDificultad.setValue(h.getNivelDificultad());
            txtActualizarPagoMensual.setText(String.valueOf(h.getPagoMensual()));

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese un ID válido.");
        }
    }

    // --------------------
    // ACTUALIZAR
    // --------------------
    private void actualizarHeroe() {
        try {
            int id = Integer.parseInt(txtActualizarID.getText().trim());
            String nombre = txtActualizarNombre.getText().trim();
            String superpoder = txtActualizarSuperpoder.getText().trim();
            String mision = txtActualizarmision.getText().trim();
            int nivel = (Integer) spiActualizarDificultad.getValue();
            double pagoMensual = Double.parseDouble(txtActualizarPagoMensual.getText().trim());

            if (nombre.isEmpty() || superpoder.isEmpty() || mision.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Complete todos los campos.");
                return;
            }

            boolean ok = manager.actualizarHeroe(id, nombre, superpoder, mision, nivel, pagoMensual);

            if (ok) {
                JOptionPane.showMessageDialog(null, "Héroe actualizado.");
                llenarLista(manager.listarHeroesOrdenadosPorId());
            } else {
                JOptionPane.showMessageDialog(null, "No existe un héroe con ese ID.");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "ID y Pago Mensual deben ser números.");
        }
    }

    // --------------------
    // REPORTE
    // --------------------
    private void generarReporte() {
        String input = JOptionPane.showInputDialog(null, "Ingrese el ID para generar reporte:");

        if (input == null) return;

        try {
            int id = Integer.parseInt(input);
            ReporteHeroe r = manager.generarReporte(id);

            if (r != null) {
                txtReporte.setText(r.toString());
            } else {
                JOptionPane.showMessageDialog(null, "ID no encontrado.");
                txtReporte.setText("");
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
        }
    }

    private void limpiarCamposIngreso() {
        txtID.setText("");
        txtNombre.setText("");
        txtSuperpoder.setText("");
        txtMision.setText("");
        txtPagoMensual.setText("");
        spiNivelDificultad.setValue(1);
    }
}
