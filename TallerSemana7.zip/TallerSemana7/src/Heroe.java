public class Heroe {

    private int id;
    private String nombre;
    private String superpoder;
    private String mision;
    private int nivelDificultad;
    private double pagoMensual;


    public Heroe(int id, String nombre, String superpoder,
                 String mision, int nivelDificultad, double pagoMensual) {
        this.id = id;
        this.nombre = nombre;
        this.superpoder = superpoder;
        this.mision = mision;
        setNivelDificultad(nivelDificultad); // para validar 1..5
        this.pagoMensual = pagoMensual;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getSuperpoder() {
        return superpoder;
    }

    public void setSuperpoder(String superpoder) {
        this.superpoder = superpoder;
    }

    public String getMision() {
        return mision;
    }

    public void setMision(String mision) {
        this.mision = mision;
    }

    public int getNivelDificultad() {
        return nivelDificultad;
    }

    //validación que el nivel de dificultad este entre 1 y 5
    public void setNivelDificultad(int nivelDificultad) {
        if (nivelDificultad < 1) {
            this.nivelDificultad = 1;
        } else if (nivelDificultad > 5) {
            this.nivelDificultad = 5;
        } else {
            this.nivelDificultad = nivelDificultad;
        }
    }

    public double getPagoMensual() {
        return pagoMensual;
    }

    public void setPagoMensual(double pagoMensual) {
        this.pagoMensual = pagoMensual;
    }

    //Aporte al Fondo de Héroes: 10% del pago mensual
    public double calcularAporteFondo() {
        return pagoMensual * 0.10;
    }

    //Pago anual bruto
    public double calcularPagoAnualBruto() {
        return pagoMensual * 12;
    }

    //Impuesto anual según la tabla del enunciado
    public double calcularImpuestoAnual() {
        double pagoAnual = calcularPagoAnualBruto();
        double impuestoAnual = 0.0;

        if (pagoAnual <= 60000) {
            impuestoAnual = 0;
        } else if (pagoAnual <= 120000) {
            impuestoAnual = (pagoAnual - 60000) * 0.12;
        } else if (pagoAnual <= 240000) {
            impuestoAnual = (pagoAnual - 120000) * 0.25;
        } else { // pagoAnual > 240000
            impuestoAnual = (pagoAnual - 240000) * 0.35;
        }

        return impuestoAnual;
    }

    //Impuesto mensual
    public double calcularImpuestoMensual() {
        return calcularImpuestoAnual() / 12.0;
    }

    //Pago neto mensual = pagoMensual - aporte - impuesto mensual
    public double calcularPagoNetoMensual() {
        double aporte = calcularAporteFondo();
        double impuestoMensual = calcularImpuestoMensual();
        return pagoMensual - aporte - impuestoMensual;
    }

    @Override
    public String toString() {
        return "Héroe  " +
                "ID: " + id +
                ", Nombre: " + nombre +
                ", Superpoder: " + superpoder +
                ", Misión: " + mision +
                ", Nivel: " + nivelDificultad +
                ", Pago mensual: " + pagoMensual;
    }
}