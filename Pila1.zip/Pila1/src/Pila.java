import java.util.Stack;

public class Pila {

    private Stack<Publicacion> coleccion;

    public Pila(){
        coleccion=new Stack<Publicacion>();
    }

    public void push(Publicacion obj){
        coleccion.push(obj);
    }

    public Publicacion pop() throws Exception{
        if(!coleccion.isEmpty())
            return coleccion.pop();
        throw new Exception("Pila Vacia");
    }

    public Publicacion top() throws Exception{
        if(coleccion.isEmpty())
            throw new Exception("Pila esta Vacia");
        return coleccion.peek();
    }

    @Override
    public String toString() {
        String respuesta="";

        for(int i=coleccion.size()-1; i>=0; i--){
            respuesta+= coleccion.get(i).toString()+"\n";

        }
        return "Pila:\n" + respuesta;
    }
}
